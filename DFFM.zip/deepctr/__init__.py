from .utils import check_version

__version__ = '0.8.6'
check_version(__version__)
