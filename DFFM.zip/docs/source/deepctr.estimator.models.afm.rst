deepctr.estimator.models.afm module
===================================

.. automodule:: deepctr.estimator.models.afm
    :members:
    :no-undoc-members:
    :no-show-inheritance:
