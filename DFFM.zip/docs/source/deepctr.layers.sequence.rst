deepctr.layers.sequence module
==============================

.. automodule:: deepctr.layers.sequence
    :members:
    :no-undoc-members:
    :no-show-inheritance:
