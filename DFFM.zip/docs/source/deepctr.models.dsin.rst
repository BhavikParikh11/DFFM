deepctr.models.dsin module
==========================

.. automodule:: deepctr.models.dsin
    :members:
    :no-undoc-members:
    :no-show-inheritance:
