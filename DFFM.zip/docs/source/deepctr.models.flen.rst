deepctr.models.flen module
=============================

.. automodule:: deepctr.models.flen
    :members:
    :no-undoc-members:
    :no-show-inheritance:
