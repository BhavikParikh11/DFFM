deepctr.estimator.models.fnn module
===================================

.. automodule:: deepctr.estimator.models.fnn
    :members:
    :no-undoc-members:
    :no-show-inheritance:
