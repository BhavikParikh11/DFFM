deepctr.models.ifm module
=============================

.. automodule:: deepctr.models.ifm
    :members:
    :no-undoc-members:
    :no-show-inheritance:
