deepctr.estimator.models.pnn module
===================================

.. automodule:: deepctr.estimator.models.pnn
    :members:
    :no-undoc-members:
    :no-show-inheritance:
