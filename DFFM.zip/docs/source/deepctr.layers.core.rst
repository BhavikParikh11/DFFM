deepctr.layers.core module
==========================

.. automodule:: deepctr.layers.core
    :members:
    :no-undoc-members:
    :no-show-inheritance:
