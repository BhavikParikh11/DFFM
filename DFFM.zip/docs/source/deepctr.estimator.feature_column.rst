deepctr.estimator.feature\_column module
========================================

.. automodule:: deepctr.estimator.feature_column
    :members:
    :undoc-members:
    :show-inheritance:
