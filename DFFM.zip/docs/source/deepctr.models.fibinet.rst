deepctr.models.fibinet module
=============================

.. automodule:: deepctr.models.fibinet
    :members:
    :no-undoc-members:
    :no-show-inheritance:
