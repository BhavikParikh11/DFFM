deepctr.estimator.models.nfm module
===================================

.. automodule:: deepctr.estimator.models.nfm
    :members:
    :no-undoc-members:
    :no-show-inheritance:
