deepctr.feature\_column module
==============================

.. automodule:: deepctr.feature_column
    :members:
    :undoc-members:
    :show-inheritance:
