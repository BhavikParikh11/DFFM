DeepCTR Layers API
======================


.. toctree::
   :maxdepth: 3
   :caption: API:

   Core Layers<deepctr.layers.core>
   Interaction Layers<deepctr.layers.interaction>
   Activation Layers<deepctr.layers.activation>
   Normalization Layers<deepctr.layers.normalization>
   Sequence Layers<deepctr.layers.sequence>