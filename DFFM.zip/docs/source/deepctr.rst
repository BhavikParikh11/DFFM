deepctr package
===============

Subpackages
-----------

.. toctree::

    deepctr.contrib
    deepctr.layers
    deepctr.models

Submodules
----------

.. toctree::

   deepctr.inputs
   deepctr.utils

Module contents
---------------

.. automodule:: deepctr
    :members:
    :undoc-members:
    :show-inheritance:
