deepctr.layers package
======================

Submodules
----------

.. toctree::

   deepctr.layers.activation
   deepctr.layers.core
   deepctr.layers.interaction
   deepctr.layers.normalization
   deepctr.layers.sequence
   deepctr.layers.utils

Module contents
---------------

.. automodule:: deepctr.layers
    :members:
    :undoc-members:
    :show-inheritance:
