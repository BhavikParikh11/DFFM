DeepCTR Estimators API
======================

.. toctree::
   CCPM<deepctr.estimator.models.ccpm>
   FNN<deepctr.estimator.models.fnn>
   PNN<deepctr.estimator.models.pnn>
   WDL<deepctr.estimator.models.wdl>
   DeepFM<deepctr.estimator.models.deepfm>
   NFM<deepctr.estimator.models.nfm>
   AFM<deepctr.estimator.models.afm>
   DCN<deepctr.estimator.models.dcn>
   xDeepFM<deepctr.estimator.models.xdeepfm>
   AutoInt<deepctr.estimator.models.autoint>
   FiBiNET<deepctr.estimator.models.fibinet>
