deepctr.estimator.models.fibinet module
=======================================

.. automodule:: deepctr.estimator.models.fibinet
    :members:
    :no-undoc-members:
    :no-show-inheritance:
